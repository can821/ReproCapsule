module.exports = record => ({ label: record.displayName });
