module.exports = record => record.label.trim();
